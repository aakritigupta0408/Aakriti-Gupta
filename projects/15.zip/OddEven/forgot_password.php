<?php

include 'header.inc.php';

echo 'Success';

?>