<?php
echo 'An error has occured. Could not connect to Dtabase';
?>