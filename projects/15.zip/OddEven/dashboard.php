<html>

<head>
	<script type="text/javascript" src="js/jquery.js"></script>
  	<script type="text/javascript" src="js/bootstrap.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
	<!-- <link rel="stylesheet" type="text/css" href="css/style.css"> -->
</head>

<body>

	<!-- <div id="wrapper"> -->

		<div class="navbar navbar-fixed-top">
			<div class="navbar-inner">
				<div class="container">
					<a href="#" class="brand">Hello</a>
					<div class="collapse nav-collapse">
						<ul class="nav pull-right">
							<li class="active"><a href="#">Home</a></li>
							<li><a href="#">Home</a></li>
							<li><a href="#">Home</a></li>
							<li><a href="#">Home</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
<!-- 
		<div id="sidebar-wrapper">
			<ul class="sidebar-nav">

				<li><a href="#">Home</a></li>
				<li><a href="#">Home</a></li>
				<li><a href="#">Home</a></li>
				<li><a href="#">Home</a></li>



			</ul>
		</div>
 -->
		<!-- <div id="page-content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-12">


					</div>



				</div>

			</div>


		</div> -->

	<!-- </div> -->


</body>

</html>