<html>
<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/jquery-ui.js"></script>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAq3k9MvDbfTDMsx6tOycIs0-HWtRDY0Rw&sensor=false">
	</script>
	<link rel="stylesheet" href="css/jquery-ui-1.8.18.custom.css"/>
	<script type="text/javascript">
	
	var map;
	var geocoder;
	
	function initialize() {
		var mapOptions = {
			center: new google.maps.LatLng(28.644800, 77.216721),
			zoom: 11,
			mapTypeId: google.maps.MapTypeId.ROADMAP
		};
		map = new google.maps.Map(document.getElementById("map_canvas"),
			mapOptions);

		geocoder = new google.maps.Geocoder();
	}

	$(document).ready(function(){
              $("#autocomplete").autocomplete({
                  source:function(request,response){
                      geocoder.geocode({'address':request.term},function(results){
                          response($.map(results,function(item){
                              return {
                                 label:item.formatted_address,
                                 value:item.formatted_address,
                                 latitude:item.geometry.location.lat(),
                                 longitude:item.geometry.location.lng(),
                              }
                              
                          }))
                      })
                 },
                  select:function(event,ui) {
                    var location    =   new google.maps.LatLng(ui.item.latitude,ui.item.longitude);
                    marker          =   new google.maps.Marker({
                        map:map,
                        draggable:true
                    })
                   var stringvalue     =   'latitude:<input type="text" value="'+ui.item.latitude+'" >Longitude:<input type="text" value="'+ui.item.longitude+'"><br/>';
                    $("#value").append(stringvalue);
                    marker.setPosition(location);
                    map.setCenter(location);
                    
                    
                }
                  
              })
          
            });

	</script>
</head>
<body onload="initialize()">
	<input type="text" id="autocomplete">

	<div id="map_canvas" style="width:500px;height:500px;float:left;">

	</div>

</body>
</html>