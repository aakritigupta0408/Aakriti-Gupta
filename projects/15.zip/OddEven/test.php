<?php

	session_start();

?>

<html>

<head>
	<script type="text/javascript" src="fbapp/fb.js"></script>
</head>

<body>

<div class="fb-login-button" data-scope="public_profile,email" onlogin="checkLoginState()"></div>

<h1>Welcome <?php echo $_SESSION['email']; ?></h1>

</body>


</html>