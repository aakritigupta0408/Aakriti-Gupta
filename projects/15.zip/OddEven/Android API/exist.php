<?php

if(isset($_POST['email'])){

	$email = $_POST['email'];

	if(!empty($email)){

		require ('db_connect.inc.php');

		$query = "Select * from people where email = '".mysql_real_escape_string($email)."'";

		if($query_run = mysql_query($query)){

			$rows = mysql_num_rows($query_run);

			if($rows == 0)
				echo 'failure';

			else
				echo 'success';
		}
	}
	
}

?>