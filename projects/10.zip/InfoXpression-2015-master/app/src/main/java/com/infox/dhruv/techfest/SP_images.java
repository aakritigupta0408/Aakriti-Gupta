package com.infox.dhruv.techfest;

/**
 * Created by Dhruv on 11-Mar-15.
 */
public class SP_images {
    public int image_id;

    public SP_images(int fest) {
        this.image_id= fest;
    }

    public int getImage_id() {
        return image_id;
    }

    public void setImage_id(int image_id) {
        this.image_id = image_id;
    }
}
